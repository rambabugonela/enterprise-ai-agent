package com.rambabu.agent.planner;

import com.rambabu.agent.dto.ExecutionPlan;
import lombok.RequiredArgsConstructor;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import static com.rambabu.agent.planner.PromptConstants.PLANNER_PROMPT;

@Service
@RequiredArgsConstructor
public class LlmAgentPlanner implements AgentPlanner {

    private final ChatClient chatClient;
    @Value("classpath:prompts/agent-planner.txt")
    private Resource plannerTemplate;

    @Override
    public ExecutionPlan createPlan(String question) {


        Prompt prompt = new Prompt(PLANNER_PROMPT.formatted(question));
        try {
            ExecutionPlan plan =
                    chatClient
                            .prompt(prompt)
                            .call()
                            .entity(ExecutionPlan.class);
            return plan;

        } catch (Exception ex) {


            ex.printStackTrace();

            throw new RuntimeException(
                    "Failed to generate execution plan",
                    ex);

        }

    }
}